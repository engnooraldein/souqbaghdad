import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Eye, EyeOff, Mail, Lock, User, Phone, AlertCircle, Check, ArrowLeft, Facebook, Chrome, Gamepad2, Home, Smartphone, Car, Heart, Bell, Plus, Sun, Moon, LogOut, Star, Play, X, Search, MapPin, Clock, Eye as ViewIcon, Phone as PhoneIcon, Camera, Grid, List, Menu, MessageSquare, Share2, BookmarkPlus, BookmarkCheck, TrendingUp, Calendar, Users, Zap, CheckCircle, XCircle, Loader2, ChevronRight, Award, Shield, Clock3, BarChart3, ImagePlus, Trash2, ArrowUpDown } from 'lucide-react';

// Sound effects using Web Audio API
const useSound = () => {
  const audioContext = useRef<AudioContext | null>(null);

  const playSound = (type: 'success' | 'error' | 'notification' | 'click' | 'info') => {
    try {
      if (!audioContext.current) {
        audioContext.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      const ctx = audioContext.current;
      const oscillator = ctx.createOscillator();
      const gainNode = ctx.createGain();

      oscillator.connect(gainNode);
      gainNode.connect(ctx.destination);

      switch (type) {
        case 'success':
          oscillator.frequency.setValueAtTime(800, ctx.currentTime);
          oscillator.frequency.setValueAtTime(1000, ctx.currentTime + 0.1);
          gainNode.gain.setValueAtTime(0.3, ctx.currentTime);
          gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.3);
          oscillator.start(ctx.currentTime);
          oscillator.stop(ctx.currentTime + 0.3);
          break;
        case 'error':
          oscillator.frequency.setValueAtTime(400, ctx.currentTime);
          oscillator.frequency.setValueAtTime(300, ctx.currentTime + 0.1);
          gainNode.gain.setValueAtTime(0.3, ctx.currentTime);
          gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.2);
          oscillator.start(ctx.currentTime);
          oscillator.stop(ctx.currentTime + 0.2);
          break;
        case 'notification':
          oscillator.frequency.setValueAtTime(600, ctx.currentTime);
          oscillator.frequency.setValueAtTime(800, ctx.currentTime + 0.1);
          oscillator.frequency.setValueAtTime(1000, ctx.currentTime + 0.2);
          gainNode.gain.setValueAtTime(0.2, ctx.currentTime);
          gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.4);
          oscillator.start(ctx.currentTime);
          oscillator.stop(ctx.currentTime + 0.4);
          break;
        case 'click':
          oscillator.frequency.setValueAtTime(500, ctx.currentTime);
          gainNode.gain.setValueAtTime(0.1, ctx.currentTime);
          gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.05);
          oscillator.start(ctx.currentTime);
          oscillator.stop(ctx.currentTime + 0.05);
          break;
        case 'info':
          oscillator.frequency.setValueAtTime(700, ctx.currentTime);
          oscillator.frequency.setValueAtTime(900, ctx.currentTime + 0.15);
          gainNode.gain.setValueAtTime(0.2, ctx.currentTime);
          gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.3);
          oscillator.start(ctx.currentTime);
          oscillator.stop(ctx.currentTime + 0.3);
          break;
      }
    } catch (e) {
      // Audio not supported
    }
  };

  return playSound;
};

// Format price with commas
const formatPrice = (price: string | number): string => {
  const num = typeof price === 'string' ? parseInt(price.replace(/,/g, '')) : price;
  return num.toLocaleString('en-US');
};

// Format date
const formatDate = (dateStr: string): string => {
  const date = new Date(dateStr);
  return date.toLocaleDateString('ar-IQ', { year: 'numeric', month: 'short', day: 'numeric' });
};

// Logo Component with Iraqi Eagle
function Logo() {
  return (
    <div className="flex items-center gap-3">
      <div className="w-14 h-14 bg-gradient-to-br from-blue-900 to-blue-950 rounded-xl flex items-center justify-center shadow-lg golden-glow border-2 border-amber-500/30">
        <svg viewBox="0 0 120 120" className="w-10 h-10">
          <defs>
            <linearGradient id="eagleGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#d4af37" />
              <stop offset="50%" stopColor="#f4d03f" />
              <stop offset="100%" stopColor="#d4af37" />
            </linearGradient>
          </defs>
          <ellipse cx="60" cy="50" rx="25" ry="20" fill="url(#eagleGrad)" />
          <path d="M35 50 Q20 35 15 55 Q10 75 30 70" fill="url(#eagleGrad)" opacity="0.9" />
          <path d="M85 50 Q100 35 105 55 Q110 75 90 70" fill="url(#eagleGrad)" opacity="0.9" />
          <circle cx="60" cy="35" r="12" fill="url(#eagleGrad)" />
          <path d="M72 33 L85 38 L72 42 Z" fill="#d4af37" />
          <path d="M50 25 Q60 15 70 25 Q60 20 50 25" fill="#d4af37" />
          <path d="M45 55 L75 55 L75 85 L60 95 L45 85 Z" fill="#1e3a8a" stroke="#d4af37" strokeWidth="2" />
          <rect x="48" y="60" width="24" height="6" fill="#ffffff" />
          <rect x="48" y="66" width="24" height="6" fill="#000000" />
          <rect x="48" y="72" width="24" height="6" fill="#ce1126" />
          <path d="M50 90 Q45 100 40 105 M55 92 Q52 102 48 107" stroke="url(#eagleGrad)" strokeWidth="3" strokeLinecap="round" fill="none" />
          <path d="M70 90 Q75 100 80 105 M65 92 Q68 102 72 107" stroke="url(#eagleGrad)" strokeWidth="3" strokeLinecap="round" fill="none" />
        </svg>
      </div>
      <div>
        <h1 className="text-2xl font-bold text-white">سوك بغداد</h1>
        <p className="text-amber-400 text-sm">السوق الرقمي العراقي</p>
      </div>
    </div>
  );
}

// Demo Ad Badge Component
function DemoBadge({ size = 'sm' }: { size?: 'sm' | 'lg' }) {
  return (
    <span className={`bg-gradient-to-r from-amber-500 to-yellow-500 text-black font-bold px-2 py-1 rounded-lg flex items-center gap-1 ${size === 'lg' ? 'text-sm' : 'text-xs'}`}>
      <Zap className="w-3 h-3" />
      <span>تجريبي</span>
    </span>
  );
}

// Demo Banner Component
function DemoBanner({ onDismiss }: { onDismiss: () => void }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="bg-gradient-to-r from-amber-500/20 to-yellow-500/20 border border-amber-500/30 rounded-xl p-4 mb-4"
    >
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 bg-amber-500/20 rounded-full flex items-center justify-center">
          <Zap className="w-5 h-5 text-amber-400" />
        </div>
        <div className="flex-1">
          <h4 className="text-white font-bold mb-1">إعلانات تجريبية</h4>
          <p className="text-gray-300 text-sm">هذه إعلانات تجريبية لعرض طريقة عمل المنصة. عند وصول عدد كافٍ من الإعلانات الحقيقية سيتم إيقافها تلقائياً.</p>
        </div>
        <button onClick={onDismiss} className="p-2 bg-gray-700 rounded-lg text-gray-400 hover:text-white hover:bg-gray-600">
          <X className="w-4 h-4" />
        </button>
      </div>
    </motion.div>
  );
}

// Toast Notification Component
function ToastNotification({ message, type, isVisible, onClose }: { message: string; type: 'success' | 'error' | 'info'; isVisible: boolean; onClose: () => void }) {
  useEffect(() => {
    if (isVisible) {
      const timer = setTimeout(onClose, 4000);
      return () => clearTimeout(timer);
    }
  }, [isVisible, onClose]);

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, y: -50, scale: 0.9 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -50, scale: 0.9 }}
          className={`fixed top-4 left-1/2 -translate-x-1/2 z-[100] px-6 py-4 rounded-2xl shadow-2xl flex items-center gap-3 ${
            type === 'success' ? 'bg-gradient-to-r from-green-500 to-emerald-500' :
            type === 'error' ? 'bg-gradient-to-r from-red-500 to-rose-500' :
            'bg-gradient-to-r from-blue-500 to-cyan-500'
          }`}
        >
          {type === 'success' ? <CheckCircle className="w-6 h-6 text-white" /> :
           type === 'error' ? <XCircle className="w-6 h-6 text-white" /> :
           <Zap className="w-6 h-6 text-white" />}
          <span className="text-white font-bold">{message}</span>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

// Loading Overlay Component
function LoadingOverlay({ isLoading, message }: { isLoading: boolean; message: string }) {
  return (
    <AnimatePresence>
      {isLoading && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-sm flex items-center justify-center"
        >
          <div className="bg-gray-900 rounded-3xl p-8 text-center shadow-2xl border border-gray-700">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
              className="w-16 h-16 border-4 border-amber-500 border-t-transparent rounded-full mx-auto mb-4"
            />
            <p className="text-white font-bold text-lg">{message}</p>
            <p className="text-amber-400 text-sm mt-2">يرجى الانتظار...</p>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

// Seller Trust Card Component
function SellerTrustCard({ seller, adCount = 0, soldCount = 0, responseRate = 95, avgResponseTime = '5 دقائق' }: any) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-2xl p-4 border border-gray-700"
    >
      <div className="flex items-center gap-4 mb-4">
        <div className="relative">
          <img src={seller.avatar || 'https://api.dicebear.com/7.x/avataaars/svg?seed=' + seller.name} alt={seller.name} className="w-14 h-14 rounded-full border-2 border-amber-500" />
          {seller.isVerified && (
            <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center">
              <CheckCircle className="w-4 h-4 text-white" />
            </div>
          )}
        </div>
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <h3 className="text-white font-bold">{seller.name}</h3>
            {seller.isVerified && (
              <span className="px-2 py-0.5 bg-blue-500/20 text-blue-400 text-xs rounded-full flex items-center gap-1">
                <Shield className="w-3 h-3" />
                موثق
              </span>
            )}
          </div>
          <div className="flex items-center gap-1 text-amber-400 text-sm">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className={`w-3 h-3 ${i < (seller.rating || 4.5) ? 'fill-amber-400' : 'text-gray-600'}`} />
            ))}
            <span className="text-gray-400 mr-1">({seller.rating || 4.5})</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-4">
        <div className="bg-gray-700/50 rounded-xl p-3 text-center">
          <p className="text-2xl font-bold text-amber-400">{adCount}</p>
          <p className="text-gray-400 text-xs">إعلان</p>
        </div>
        <div className="bg-gray-700/50 rounded-xl p-3 text-center">
          <p className="text-2xl font-bold text-green-400">{soldCount}</p>
          <p className="text-gray-400 text-xs">مباع</p>
        </div>
        <div className="bg-gray-700/50 rounded-xl p-3 text-center">
          <p className="text-2xl font-bold text-blue-400">{responseRate}%</p>
          <p className="text-gray-400 text-xs">معدل الرد</p>
        </div>
        <div className="bg-gray-700/50 rounded-xl p-3 text-center">
          <p className="text-2xl font-bold text-purple-400">{avgResponseTime}</p>
          <p className="text-gray-400 text-xs">متوسط الرد</p>
        </div>
      </div>

      <div className="flex items-center gap-2 text-gray-400 text-sm">
        <Calendar className="w-4 h-4" />
        <span>انضم {seller.joinedDate || 'منذ 6 أشهر'}</span>
        <span className="mx-2">•</span>
        <MapPin className="w-4 h-4" />
        <span>{seller.location || 'بغداد'}</span>
      </div>
    </motion.div>
  );
}

// Auth Page Component
function AuthPage({ onLogin }: { onLogin: () => void }) {
  const [isLogin, setIsLogin] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const playSound = useSound();

  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [registerName, setRegisterName] = useState('');
  const [registerEmail, setRegisterEmail] = useState('');
  const [registerPassword, setRegisterPassword] = useState('');
  const [registerPhone, setRegisterPhone] = useState('');
  const [registerCity, setRegisterCity] = useState('بغداد');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);
    playSound('click');

    setTimeout(() => {
      if (loginPassword.length >= 4) {
        const userData = {
          id: 'user-' + Date.now(),
          name: loginEmail.split('@')[0] || registerName || 'مستخدم',
          email: loginEmail,
          phone: '07701234567',
          role: 'user',
          avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=' + loginEmail,
          cover: 'https://images.unsplash.com/photo-1579546929518-9e396f3b809b?w=800',
          bio: 'بائع موثوق في سوك بغداد',
          location: 'بغداد',
          rating: 4.8,
          isVerified: loginEmail.includes('admin'),
          joinedDate: 'منذ 8 أشهر',
          stats: { ads: 12, favorites: 5, views: 890 },
          sellerStats: { totalAds: 15, sold: 8, responseRate: 98, avgResponseTime: '3 دقائق' },
        };
        localStorage.setItem('souqUser', JSON.stringify(userData));
        setSuccess('تم تسجيل الدخول بنجاح!');
        playSound('success');
        setTimeout(onLogin, 1000);
      } else {
        setError('كلمة المرور غير صحيحة');
        playSound('error');
      }
      setIsLoading(false);
    }, 1500);
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);
    playSound('click');

    setTimeout(() => {
      if (registerPassword.length >= 4 && registerPhone.length >= 10) {
        const userData = {
          id: 'user-' + Date.now(),
          name: registerName,
          email: registerEmail,
          phone: registerPhone,
          city: registerCity,
          role: 'user',
          avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=' + registerName,
          cover: 'https://images.unsplash.com/photo-1579546929518-9e396f3b809b?w=800',
          bio: '',
          location: registerCity,
          rating: 0,
          isVerified: false,
          joinedDate: 'الآن',
          stats: { ads: 0, favorites: 0, views: 0 },
          sellerStats: { totalAds: 0, sold: 0, responseRate: 0, avgResponseTime: '-' },
        };
        localStorage.setItem('souqUser', JSON.stringify(userData));
        setSuccess('تم إنشاء حسابك بنجاح! مرحباً بك في سوك بغداد');
        playSound('success');
        setTimeout(onLogin, 1500);
      } else {
        setError('يرجى ملء جميع الحقول بشكل صحيح');
        playSound('error');
      }
      setIsLoading(false);
    }, 2000);
  };

  const cities = ['بغداد', 'أربيل', 'البصرة', 'نينوى', 'كربلاء', 'النجف', 'دهوك', 'السليمانية', 'بابل', 'ديالى'];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-blue-900 flex items-center justify-center p-4">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-20 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl" />
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-blue-400/10 rounded-full blur-3xl" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] border border-blue-500/10 rounded-full" />
      </div>

      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-md relative z-10"
      >
        <div className="text-center mb-8">
          <Logo />
        </div>

        <div className="bg-white/10 backdrop-blur-xl rounded-3xl p-8 border border-white/20">
          <div className="text-center mb-6">
            <motion.div
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="text-5xl mb-3"
            >
              🔐
            </motion.div>
            <h1 className="text-2xl font-bold text-white mb-2">
              {isLogin ? 'تسجيل الدخول' : 'إنشاء حساب جديد'}
            </h1>
            <p className="text-gray-400 text-sm">
              {isLogin ? 'مرحباً بعودتك!' : 'انضم إلينا اليوم'}
            </p>
          </div>

          <AnimatePresence>
            {error && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="bg-red-500/20 border border-red-500/30 rounded-xl p-3 mb-4 flex items-center gap-2"
              >
                <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0" />
                <span className="text-red-400 text-sm">{error}</span>
              </motion.div>
            )}
            {success && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="bg-green-500/20 border border-green-500/30 rounded-xl p-3 mb-4 flex items-center gap-2"
              >
                <Check className="w-5 h-5 text-green-400 flex-shrink-0" />
                <span className="text-green-400 text-sm">{success}</span>
              </motion.div>
            )}
          </AnimatePresence>

          {isLoading ? (
            <div className="flex flex-col items-center py-8">
              <Loader2 className="w-12 h-12 text-amber-400 animate-spin mb-4" />
              <p className="text-white font-medium">جاري التحميل...</p>
            </div>
          ) : isLogin ? (
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="text-gray-300 text-sm mb-2 block">البريد الإلكتروني أو الهاتف</label>
                <div className="relative">
                  <Mail className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    value={loginEmail}
                    onChange={(e) => setLoginEmail(e.target.value)}
                    placeholder="example@email.com"
                    required
                    className="w-full bg-gray-800/50 text-white placeholder-gray-400 rounded-xl py-3 pr-12 pl-4 border border-gray-700 focus:border-amber-400 focus:ring-2 focus:ring-amber-400/20 transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="text-gray-300 text-sm mb-2 block">كلمة المرور</label>
                <div className="relative">
                  <Lock className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="••••••••"
                    required
                    className="w-full bg-gray-800/50 text-white placeholder-gray-400 rounded-xl py-3 pr-12 pl-4 border border-gray-700 focus:border-amber-400 focus:ring-2 focus:ring-amber-400/20 transition-all"
                  />
                  <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white">
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              <motion.button type="submit" whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
                className="w-full py-4 bg-gradient-to-r from-amber-500 to-yellow-500 text-black font-bold rounded-xl hover:shadow-lg hover:shadow-amber-500/30 transition-all">
                تسجيل الدخول
              </motion.button>
            </form>
          ) : (
            <form onSubmit={handleRegister} className="space-y-4">
              <div>
                <label className="text-gray-300 text-sm mb-2 block">الاسم الكامل</label>
                <div className="relative">
                  <User className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input type="text" value={registerName} onChange={(e) => setRegisterName(e.target.value)}
                    placeholder="أحمد محمد" required
                    className="w-full bg-gray-800/50 text-white placeholder-gray-400 rounded-xl py-3 pr-12 pl-4 border border-gray-700 focus:border-amber-400" />
                </div>
              </div>

              <div>
                <label className="text-gray-300 text-sm mb-2 block">البريد الإلكتروني</label>
                <div className="relative">
                  <Mail className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input type="email" value={registerEmail} onChange={(e) => setRegisterEmail(e.target.value)}
                    placeholder="example@email.com" required
                    className="w-full bg-gray-800/50 text-white placeholder-gray-400 rounded-xl py-3 pr-12 pl-4 border border-gray-700 focus:border-amber-400" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-gray-300 text-sm mb-2 block">رقم الهاتف</label>
                  <div className="relative">
                    <Phone className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input type="tel" value={registerPhone} onChange={(e) => setRegisterPhone(e.target.value)}
                      placeholder="07XXXXXXXXX" required
                      className="w-full bg-gray-800/50 text-white placeholder-gray-400 rounded-xl py-3 pr-12 pl-4 border border-gray-700 focus:border-amber-400" />
                  </div>
                </div>
                <div>
                  <label className="text-gray-300 text-sm mb-2 block">المدينة</label>
                  <select value={registerCity} onChange={(e) => setRegisterCity(e.target.value)}
                    className="w-full bg-gray-800/50 text-white rounded-xl py-3 px-4 border border-gray-700 focus:border-amber-400">
                    {cities.map((city) => <option key={city} value={city}>{city}</option>)}
                  </select>
                </div>
              </div>

              <div>
                <label className="text-gray-300 text-sm mb-2 block">كلمة المرور</label>
                <div className="relative">
                  <Lock className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input type={showPassword ? 'text' : 'password'} value={registerPassword}
                    onChange={(e) => setRegisterPassword(e.target.value)} placeholder="4 أحرف على الأقل" required minLength={4}
                    className="w-full bg-gray-800/50 text-white placeholder-gray-400 rounded-xl py-3 pr-12 pl-4 border border-gray-700 focus:border-amber-400" />
                  <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white">
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              <motion.button type="submit" whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
                className="w-full py-4 bg-gradient-to-r from-amber-500 to-yellow-500 text-black font-bold rounded-xl hover:shadow-lg hover:shadow-amber-500/30 transition-all">
                إنشاء حساب
              </motion.button>
            </form>
          )}

          <div className="mt-6">
            <div className="flex items-center gap-4 mb-4">
              <div className="flex-1 h-px bg-gray-700" />
              <span className="text-gray-400 text-sm">أو</span>
              <div className="flex-1 h-px bg-gray-700" />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <motion.button whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}
                className="flex items-center justify-center gap-2 py-3 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors">
                <Facebook className="w-5 h-5" />
                <span className="text-sm">فيسبوك</span>
              </motion.button>
              <motion.button whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}
                className="flex items-center justify-center gap-2 py-3 bg-white text-gray-800 rounded-xl hover:bg-gray-100 transition-colors">
                <Chrome className="w-5 h-5" />
                <span className="text-sm">جوجل</span>
              </motion.button>
            </div>
          </div>

          <div className="mt-6 text-center">
            <button onClick={() => { setIsLogin(!isLogin); setError(''); setSuccess(''); }}
              className="text-gray-400 hover:text-amber-400 text-sm transition-colors">
              {isLogin ? 'ليس لديك حساب؟ سجل الآن' : 'لديك حساب؟ تسجيل الدخول'}
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

// Enhanced Ads Data with more info
const adsData = [
  { id: 1, title: 'Toyota Land Cruiser 2024', price: '850000000', location: 'بغداد - المنصور', phone: '07701234567', category: 'cars', images: ['https://images.unsplash.com/photo-1625231334168-2e3c5d7d6b88?w=600', 'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?w=600'], seller: { name: 'أحمد العاني', avatar: 'https://i.pravatar.cc/150?img=1', isVerified: true, rating: 4.9, joinedDate: 'منذ سنة', location: 'بغداد - المنصور' }, time: 'منذ ساعة', views: 1245, status: 'active', createdAt: '2024-01-15', updatedAt: '2024-01-20', type: 'sell', description: 'سيارة فاخرة بحالة ممتازة، ماشية 15,000 كم، فل كامل، بدون حوادث', adCount: 15, soldCount: 8, responseRate: 98, avgResponseTime: '3 دقائق' },
  { id: 2, title: 'فيلا 400 متر للبيع', price: '1200000000', location: 'أربيل - مركز المدينة', phone: '07501234567', category: 'real-estate', images: ['https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=600'], seller: { name: 'محمد الركابي', avatar: 'https://i.pravatar.cc/150?img=2', isVerified: true, rating: 4.7, joinedDate: 'منذ 8 أشهر', location: 'أربيل' }, time: 'منذ 3 ساعات', views: 892, status: 'active', createdAt: '2024-01-18', updatedAt: '2024-01-19', type: 'sell', description: 'فيلا جديدة 6 غرف نوم، صالة كبيرة، حديقة، كراج', adCount: 8, soldCount: 5, responseRate: 95, avgResponseTime: '10 دقائق' },
  { id: 3, title: 'iPhone 15 Pro Max 256GB', price: '950000', location: 'بغداد - الكرادة', phone: '07801234567', category: 'phones', images: ['https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=600', 'https://images.unsplash.com/photo-1592899677977-9c10ca588bbd?w=600'], seller: { name: 'Ali Hassan', avatar: 'https://i.pravatar.cc/150?img=3', isVerified: false, rating: 4.5, joinedDate: 'منذ 3 أشهر', location: 'بغداد' }, time: 'منذ 5 ساعات', views: 456, status: 'active', createdAt: '2024-01-19', updatedAt: '2024-01-20', type: 'sell', description: 'آيفون جديد بالضمان، لون تيتانيوم أزرق، غير مستخدم', adCount: 4, soldCount: 2, responseRate: 88, avgResponseTime: '15 دقيقة' },
  { id: 4, title: 'Mercedes G63 AMG 2023', price: '1500000000', location: 'البصرة', phone: '07721234567', category: 'cars', images: ['https://images.unsplash.com/photo-1552519507-da3b142c6e3d?w=600'], seller: { name: 'سعد المالكي', avatar: 'https://i.pravatar.cc/150?img=4', isVerified: true, rating: 4.8, joinedDate: 'منذ سنة ونصف', location: 'البصرة' }, time: 'منذ يوم', views: 2341, status: 'active', createdAt: '2024-01-10', updatedAt: '2024-01-18', type: 'sell', description: 'جيب مرسيدس فاخر، ماشية قليل، كلشي موجود', adCount: 22, soldCount: 15, responseRate: 99, avgResponseTime: '2 دقائق' },
  { id: 5, title: 'Samsung Galaxy S24 Ultra', price: '800000', location: 'نينوى', phone: '07531234567', category: 'phones', images: ['https://images.unsplash.com/photo-1610945415295-d9bbf67e5972?w=600'], seller: { name: 'Omar Khalid', avatar: 'https://i.pravatar.cc/150?img=5', isVerified: false, rating: 4.3, joinedDate: 'منذ شهرين', location: 'نينوى' }, time: 'منذ يوم', views: 234, status: 'active', createdAt: '2024-01-17', updatedAt: '2024-01-19', type: 'sell', description: 'سامسونج جديد، ضمان سنة، توصيل مجاني', adCount: 2, soldCount: 1, responseRate: 75, avgResponseTime: '30 دقيقة' },
  { id: 6, title: 'شقة 150 متر للإيجار', price: '1500000', location: 'كربلاء', phone: '07841234567', category: 'real-estate', images: ['https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=600'], seller: { name: 'حسن الموسوي', avatar: 'https://i.pravatar.cc/150?img=6', isVerified: true, rating: 4.6, joinedDate: 'منذ 6 أشهر', location: 'كربلاء' }, time: 'منذ يومين', views: 567, status: 'active', createdAt: '2024-01-12', updatedAt: '2024-01-16', type: 'rent', description: 'شقة جديدة للايجار، 3 غرف، موقع ممتاز', adCount: 6, soldCount: 3, responseRate: 92, avgResponseTime: '8 دقائق' },
  { id: 7, title: 'BMW X7 2024', price: '950000000', location: 'دهوك', phone: '07751234567', category: 'cars', images: ['https://images.unsplash.com/photo-1555215695-3004980ad54e?w=600'], seller: { name: 'Rebaz Ali', avatar: 'https://i.pravatar.cc/150?img=7', isVerified: true, rating: 4.9, joinedDate: 'منذ سنتين', location: 'دهوك' }, time: 'منذ يومين', views: 1234, status: 'active', createdAt: '2024-01-08', updatedAt: '2024-01-15', type: 'sell', description: 'بي إم دبليو جديدة، فل كامل، ماشية 5,000 كم', adCount: 18, soldCount: 12, responseRate: 100, avgResponseTime: '1 دقيقة' },
  { id: 8, title: 'MacBook Pro M3 14"', price: '1200000', location: 'السليمانية', phone: '07561234567', category: 'electronics', images: ['https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=600'], seller: { name: 'Zana Kareem', avatar: 'https://i.pravatar.cc/150?img=8', isVerified: false, rating: 4.4, joinedDate: 'منذ 4 أشهر', location: 'السليمانية' }, time: 'منذ 3 أيام', views: 345, status: 'active', createdAt: '2024-01-05', updatedAt: '2024-01-14', type: 'sell', description: 'ماك بوك برو جديد، مع شاحن، ضمان سنة', adCount: 3, soldCount: 1, responseRate: 85, avgResponseTime: '20 دقيقة' },
];

// Games Data
const gamesData = [
  { id: 1, title: 'ضارب الدجاج', emoji: '🐔💥', players: '1', rating: 4.9, description: 'لعبة ممتعة لضرب الدجاج' },
  { id: 2, title: 'ورق طاولي', emoji: '🃏', players: '2-4', rating: 4.8, description: 'لعبة ورق كلاسيكية' },
  { id: 3, title: 'داما', emoji: '🎲', players: '2', rating: 4.6, description: 'لعبة الداما الشهيرة' },
  { id: 4, title: 'سودوكو', emoji: '🧩', players: '1', rating: 4.5, description: 'لغز الأرقام' },
  { id: 5, title: 'شطرنج', emoji: '♟️', players: '2', rating: 4.7, description: 'لعبة الشطرنج' },
  { id: 6, title: 'بورت', emoji: '🎴', players: '2-4', rating: 4.4, description: 'لعبة البورت' },
];

// Create Ad Modal with enhanced features
function CreateAdModal({ isOpen, onClose, onSubmit, user }: { isOpen: boolean; onClose: () => void; onSubmit: (data: any) => void; user: any }) {
  const [formData, setFormData] = useState({
    title: '',
    price: '',
    description: '',
    category: 'cars',
    city: user?.city || 'بغداد',
    phone: user?.phone || '',
    type: 'sell',
    condition: 'excellent',
  });
  const [images, setImages] = useState<{ file: File; preview: string; progress: number }[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const playSound = useSound();

  const categories = [
    { id: 'cars', name: 'سيارات', icon: Car },
    { id: 'real-estate', name: 'عقارات', icon: Home },
    { id: 'phones', name: 'هواتف', icon: Smartphone },
    { id: 'electronics', name: 'إلكترونيات', icon: Phone },
    { id: 'furniture', name: 'أثاث', icon: Home },
  ];

  const cities = ['بغداد', 'أربيل', 'البصرة', 'نينوى', 'كربلاء', 'النجف', 'دهوك', 'السليمانية', 'بابل', 'ديالى'];

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newImages = Array.from(e.target.files).map((file) => ({
        file,
        preview: URL.createObjectURL(file),
        progress: 0,
      }));
      setImages([...images, ...newImages]);

      // Simulate upload progress
      newImages.forEach((img, index) => {
        let progress = 0;
        const interval = setInterval(() => {
          progress += Math.random() * 30;
          if (progress >= 100) {
            progress = 100;
            clearInterval(interval);
          }
          setImages((prev) =>
            prev.map((p, i) => (i === images.length + index ? { ...p, progress } : p))
          );
        }, 200);
      });
    }
  };

  const removeImage = (index: number) => {
    setImages(images.filter((_, i) => i !== index));
  };

  const formatPriceInput = (value: string) => {
    const numbers = value.replace(/[^0-9]/g, '');
    return numbers.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsUploading(true);
    playSound('click');

    // Simulate upload
    for (let i = 0; i <= 100; i += 10) {
      await new Promise((resolve) => setTimeout(resolve, 200));
      setUploadProgress(i);
    }

    setIsUploading(false);
    playSound('success');
    onSubmit({ ...formData, images: images.map((i) => i.preview) });
    onClose();
  };

  if (!isOpen) return null;

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/70" onClick={onClose} />
      <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
        className="relative bg-gray-900 rounded-3xl p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto border border-gray-700">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-white">رفع إعلان جديد</h2>
          <button onClick={onClose} className="p-2 bg-gray-800 rounded-xl text-gray-400 hover:text-white">
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            {['sell', 'rent'].map((type) => (
              <button key={type} type="button" onClick={() => setFormData({ ...formData, type })}
                className={`py-3 rounded-xl font-bold ${formData.type === type ? 'bg-amber-500 text-black' : 'bg-gray-800 text-gray-400'}`}>
                {type === 'sell' ? 'للبيع' : 'للإيجار'}
              </button>
            ))}
          </div>

          <div>
            <label className="text-gray-300 text-sm mb-2 block">التصنيف</label>
            <div className="grid grid-cols-5 gap-2">
              {categories.map((cat) => (
                <button key={cat.id} type="button" onClick={() => setFormData({ ...formData, category: cat.id })}
                  className={`p-3 rounded-xl flex flex-col items-center gap-1 ${formData.category === cat.id ? 'bg-amber-500 text-black' : 'bg-gray-800 text-gray-400'}`}>
                  <cat.icon className="w-5 h-5" />
                  <span className="text-xs">{cat.name}</span>
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-gray-300 text-sm mb-2 block">عنوان الإعلان</label>
            <input type="text" value={formData.title} onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              placeholder="مثال: Toyota Land Cruiser 2024" required
              className="w-full bg-gray-800 text-white rounded-xl py-3 px-4 border border-gray-700 focus:border-amber-400" />
          </div>

          <div>
            <label className="text-gray-300 text-sm mb-2 block">السعر (دينار عراقي)</label>
            <input type="text" value={formatPriceInput(formData.price)}
              onChange={(e) => setFormData({ ...formData, price: formatPriceInput(e.target.value) })}
              placeholder="مثال: 850,000,000" required
              className="w-full bg-gray-800 text-white rounded-xl py-3 px-4 border border-gray-700 focus:border-amber-400 text-xl font-bold" />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-gray-300 text-sm mb-2 block">المدينة</label>
              <select value={formData.city} onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                className="w-full bg-gray-800 text-white rounded-xl py-3 px-4 border border-gray-700 focus:border-amber-400">
                {cities.map((city) => <option key={city} value={city}>{city}</option>)}
              </select>
            </div>
            <div>
              <label className="text-gray-300 text-sm mb-2 block">رقم الهاتف</label>
              <input type="tel" value={formData.phone} onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                placeholder="07XXXXXXXXX" required
                className="w-full bg-gray-800 text-white rounded-xl py-3 px-4 border border-gray-700 focus:border-amber-400" />
            </div>
          </div>

          <div>
            <label className="text-gray-300 text-sm mb-2 block">وصف الإعلان</label>
            <textarea value={formData.description} onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="اكتب وصفاً مفصلاً عن المنتج..." rows={4}
              className="w-full bg-gray-800 text-white rounded-xl py-3 px-4 border border-gray-700 focus:border-amber-400 resize-none" />
          </div>

          <div>
            <label className="text-gray-300 text-sm mb-2 block">الصور ({images.length}/10)</label>
            <div className="grid grid-cols-4 gap-3 mb-3">
              {images.map((img, index) => (
                <div key={index} className="relative aspect-square rounded-xl overflow-hidden bg-gray-800">
                  <img src={img.preview} alt="" className="w-full h-full object-cover" />
                  {img.progress < 100 && (
                    <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                      <div className="w-3/4 h-1 bg-gray-700 rounded-full overflow-hidden">
                        <div className="h-full bg-amber-500" style={{ width: `${img.progress}%` }} />
                      </div>
                    </div>
                  )}
                  <button type="button" onClick={() => removeImage(index)}
                    className="absolute top-1 right-1 w-6 h-6 bg-red-500 rounded-full flex items-center justify-center">
                    <Trash2 className="w-3 h-3 text-white" />
                  </button>
                </div>
              ))}
              {images.length < 10 && (
                <label className="aspect-square rounded-xl border-2 border-dashed border-gray-700 flex flex-col items-center justify-center cursor-pointer hover:border-amber-500 transition-colors">
                  <ImagePlus className="w-8 h-8 text-gray-500 mb-1" />
                  <span className="text-xs text-gray-500">إضافة</span>
                  <input type="file" accept="image/*" multiple onChange={handleImageSelect} className="hidden" />
                </label>
              )}
            </div>
          </div>

          <motion.button type="submit" whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
            disabled={isUploading}
            className="w-full py-4 bg-gradient-to-r from-amber-500 to-yellow-500 text-black font-bold rounded-xl disabled:opacity-50 flex items-center justify-center gap-2">
            {isUploading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                <span>جاري الرفع... {uploadProgress}%</span>
              </>
            ) : (
              <>
                <CheckCircle className="w-5 h-5" />
                <span>نشر الإعلان</span>
              </>
            )}
          </motion.button>
        </form>
      </motion.div>
    </motion.div>
  );
}

// Enhanced Ad Detail Modal
function AdDetailModal({ ad, onClose, onFavorite, isFavorite }: { ad: any; onClose: () => void; onFavorite: () => void; isFavorite: boolean }) {
  const [currentImage, setCurrentImage] = useState(0);
  const playSound = useSound();

  if (!ad) return null;

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: ad.title,
        text: `شوف هذا الإعلان في سوك بغداد: ${ad.title}`,
        url: window.location.href,
      });
    }
    playSound('click');
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/70" onClick={onClose} />
      <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
        className="relative bg-gray-900 rounded-3xl w-full max-w-2xl max-h-[90vh] overflow-y-auto border border-gray-700">
        {/* Image Carousel */}
        <div className="relative aspect-video">
          <img src={ad.images[currentImage]} alt={ad.title} className="w-full h-full object-cover" />

          {ad.images.length > 1 && (
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
              {ad.images.map((_: any, i: number) => (
                <button key={i} onClick={() => setCurrentImage(i)}
                  className={`w-2 h-2 rounded-full ${i === currentImage ? 'bg-white' : 'bg-white/50'}`} />
              ))}
            </div>
          )}

          <button onClick={onClose} className="absolute top-4 right-4 p-2 bg-black/50 rounded-xl text-white hover:bg-black/70">
            <X className="w-6 h-6" />
          </button>

          <div className="absolute top-4 left-4 flex gap-2">
            <div className={`px-3 py-1 rounded-full text-sm font-bold ${ad.type === 'sell' ? 'bg-amber-500 text-black' : 'bg-blue-500 text-white'}`}>
              {ad.type === 'sell' ? 'للبيع' : 'للإيجار'}
            </div>
            <div className={`px-3 py-1 rounded-full text-sm font-bold ${ad.status === 'active' ? 'bg-green-500 text-white' : 'bg-gray-500 text-white'}`}>
              {ad.status === 'active' ? 'نشط' : 'منتهي'}
            </div>
          </div>
        </div>

        <div className="p-6">
          <h2 className="text-2xl font-bold text-white mb-2">{ad.title}</h2>

          <div className="flex items-center gap-4 mb-4">
            <span className="text-3xl font-bold text-amber-400">{formatPrice(ad.price)} د.ع</span>
          </div>

          <div className="flex flex-wrap items-center gap-4 text-gray-400 text-sm mb-6">
            <div className="flex items-center gap-1">
              <MapPin className="w-4 h-4" />
              <span>{ad.location}</span>
            </div>
            <div className="flex items-center gap-1">
              <Clock className="w-4 h-4" />
              <span>{ad.time}</span>
            </div>
            <div className="flex items-center gap-1">
              <ViewIcon className="w-4 h-4" />
              <span>{ad.views} مشاهدة</span>
            </div>
            <div className="flex items-center gap-1">
              <Calendar className="w-4 h-4" />
              <span>نشر: {formatDate(ad.createdAt)}</span>
            </div>
          </div>

          {ad.description && (
            <div className="bg-gray-800/50 rounded-xl p-4 mb-6">
              <h3 className="text-white font-bold mb-2">الوصف</h3>
              <p className="text-gray-300">{ad.description}</p>
            </div>
          )}

          {/* Seller Trust Card */}
          <SellerTrustCard
            seller={ad.seller}
            adCount={ad.adCount}
            soldCount={ad.soldCount}
            responseRate={ad.responseRate}
            avgResponseTime={ad.avgResponseTime}
          />

          {/* Contact Buttons */}
          <div className="grid grid-cols-2 gap-4 mt-6">
            <motion.a href={`https://wa.me/964${ad.phone.slice(1)}`} target="_blank" rel="noopener noreferrer"
              whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
              className="flex items-center justify-center gap-2 py-4 bg-green-500 text-white font-bold rounded-xl">
              <MessageSquare className="w-5 h-5" />
              <span>واتساب</span>
            </motion.a>
            <motion.a href={`tel:${ad.phone}`} whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
              className="flex items-center justify-center gap-2 py-4 bg-blue-500 text-white font-bold rounded-xl">
              <PhoneIcon className="w-5 h-5" />
              <span>اتصال</span>
            </motion.a>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 mt-4">
            <button onClick={() => { onFavorite(); playSound('click'); }}
              className={`flex-1 py-3 rounded-xl flex items-center justify-center gap-2 ${isFavorite ? 'bg-red-500 text-white' : 'bg-gray-800 text-white'}`}>
              {isFavorite ? <Heart className="w-5 h-5 fill-current" /> : <Heart className="w-5 h-5" />}
              <span>المفضلة</span>
            </button>
            <button onClick={handleShare} className="flex-1 py-3 bg-gray-800 text-white rounded-xl flex items-center justify-center gap-2">
              <Share2 className="w-5 h-5" />
              <span>مشاركة</span>
            </button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}

// Notifications Panel
function NotificationsPanel({ isOpen, onClose, notifications }: { isOpen: boolean; onClose: () => void; notifications: any[] }) {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
          className="fixed inset-0 z-50" onClick={onClose}>
          <div className="absolute inset-0 bg-black/60" />
          <motion.div initial={{ x: 300 }} animate={{ x: 0 }} exit={{ x: 300 }}
            className="absolute right-0 top-0 bottom-0 w-80 bg-gray-900 p-6 overflow-y-auto border-l border-gray-700">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-white">الإشعارات</h2>
              <button onClick={onClose} className="p-2 bg-gray-800 rounded-xl text-gray-400 hover:text-white">
                <X className="w-6 h-6" />
              </button>
            </div>

            {notifications.length === 0 ? (
              <div className="text-center py-12">
                <Bell className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                <p className="text-gray-400">لا توجد إشعارات</p>
              </div>
            ) : (
              <div className="space-y-3">
                {notifications.map((notif, i) => (
                  <motion.div key={i} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
                    className="bg-gray-800 rounded-xl p-4 border border-gray-700">
                    <div className="flex items-start gap-3">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${notif.type === 'message' ? 'bg-blue-500/20' : 'bg-amber-500/20'}`}>
                        {notif.type === 'message' ? <MessageSquare className="w-5 h-5 text-blue-400" /> : <Bell className="w-5 h-5 text-amber-400" />}
                      </div>
                      <div className="flex-1">
                        <p className="text-white font-medium">{notif.title}</p>
                        <p className="text-gray-400 text-sm">{notif.message}</p>
                        <p className="text-gray-500 text-xs mt-1">{notif.time}</p>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

// Main App after Login
function MainApp({ user, onLogout }: { user: any; onLogout: () => void }) {
  const [darkMode, setDarkMode] = useState(true);
  const [currentView, setCurrentView] = useState('home');
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const [showCreateAd, setShowCreateAd] = useState(false);
  const [selectedAd, setSelectedAd] = useState<any>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [sortBy, setSortBy] = useState<'recent' | 'views' | 'price-low' | 'price-high'>('recent');
  const [favorites, setFavorites] = useState<number[]>(() => {
    const saved = localStorage.getItem('souqFavorites');
    return saved ? JSON.parse(saved) : [];
  });
  const [showNotifications, setShowNotifications] = useState(false);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info'; visible: boolean }>({ message: '', type: 'info', visible: false });
  const [notifications, setNotifications] = useState([
    { type: 'message', title: 'رسالة جديدة', message: 'أحمد العاني أرسل لك رسالة', time: 'منذ 5 دقائق' },
    { type: 'alert', title: 'إعلانك نشط', message: 'تم تفعيل إعلانك بنجاح', time: 'منذ ساعة' },
    { type: 'alert', title: 'مشاهدات جديدة', message: 'إعلانك حصل على 50 مشاهدة جديدة', time: 'منذ 3 ساعات' },
  ]);

  const playSound = useSound();

  const categories = [
    { id: 'all', name: 'الكل', emoji: '📦' },
    { id: 'cars', name: 'السيارات', emoji: '🚗' },
    { id: 'real-estate', name: 'العقارات', emoji: '🏠' },
    { id: 'phones', name: 'الهواتف', emoji: '📱' },
    { id: 'electronics', name: 'إلكترونيات', emoji: '💻' },
    { id: 'games', name: 'الألعاب', emoji: '🎮' },
  ];

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
    document.documentElement.classList.toggle('dark');
    localStorage.setItem('souqTheme', darkMode ? 'light' : 'dark');
  };

  const handleLogout = () => {
    localStorage.removeItem('souqUser');
    onLogout();
  };

  const toggleFavorite = (adId: number) => {
    const newFavorites = favorites.includes(adId)
      ? favorites.filter((id) => id !== adId)
      : [...favorites, adId];
    setFavorites(newFavorites);
    localStorage.setItem('souqFavorites', JSON.stringify(newFavorites));
    playSound('click');
    setToast({
      message: favorites.includes(adId) ? 'تمت الإزالة من المفضلة' : 'تمت الإضافة للمفضلة',
      type: 'success',
      visible: true,
    });
  };

  const filteredAds = adsData
    .filter((ad) => {
      const matchesSearch = ad.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           ad.location.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = selectedCategory === 'all' || ad.category === selectedCategory;
      return matchesSearch && matchesCategory;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'views':
          return b.views - a.views;
        case 'price-low':
          return parseInt(a.price) - parseInt(b.price);
        case 'price-high':
          return parseInt(b.price) - parseInt(a.price);
        default:
          return 0;
      }
    });

  const showToast = (message: string, type: 'success' | 'error' | 'info') => {
    setToast({ message, type, visible: true });
    playSound(type);
    setTimeout(() => setToast((prev) => ({ ...prev, visible: false })), 4000);
  };

  // Games View
  if (currentView === 'games') {
    return (
      <div className="min-h-screen bg-gray-900">
        <div className="bg-gradient-to-r from-purple-900 via-blue-900 to-purple-900 pt-8 pb-16 relative overflow-hidden">
          <div className="container mx-auto px-4 relative z-10">
            <button onClick={() => setCurrentView('home')}
              className="flex items-center gap-2 text-white hover:text-amber-400 mb-4">
              <ArrowLeft className="w-6 h-6" />
              <span>رجوع</span>
            </button>
            <div className="text-center">
              <motion.div animate={{ y: [0, -10, 0] }} transition={{ duration: 2, repeat: Infinity }}
                className="text-6xl mb-4">🎮</motion.div>
              <h1 className="text-3xl font-bold text-white mb-2">منصة الألعاب</h1>
              <p className="text-gray-300">استمتع بأفضل الألعاب الترفيهية!</p>
            </div>
          </div>
        </div>
        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {gamesData.map((game) => (
              <motion.div key={game.id} whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}
                className="bg-gray-800 rounded-2xl p-6 text-center border border-gray-700 hover:border-amber-500/50 cursor-pointer">
                <div className="text-5xl mb-3">{game.emoji}</div>
                <h3 className="text-white font-bold mb-2">{game.title}</h3>
                <p className="text-gray-400 text-sm mb-3">{game.description}</p>
                <div className="flex items-center justify-center gap-2 text-gray-400 text-sm mb-4">
                  <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                  <span>{game.rating}</span>
                  <span>•</span>
                  <span>{game.players} لاعبين</span>
                </div>
                <motion.button whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}
                  className="w-full py-2 bg-amber-500 text-black font-semibold rounded-xl flex items-center justify-center gap-2">
                  <Play className="w-4 h-4" />
                  <span>لعب الآن</span>
                </motion.button>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900">
      <ToastNotification message={toast.message} type={toast.type} isVisible={toast.visible} onClose={() => setToast({ ...toast, visible: false })} />

      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-gray-900/95 backdrop-blur-lg border-b border-gray-800">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3 cursor-pointer" onClick={() => setCurrentView('home')}>
              <div className="w-10 h-10 bg-gradient-to-br from-blue-900 to-blue-950 rounded-xl flex items-center justify-center border border-amber-500/30">
                <span className="text-amber-400 text-xl">🇮🇶</span>
              </div>
              <div className="hidden sm:block">
                <h1 className="text-lg font-bold text-white">سوك بغداد</h1>
              </div>
            </div>

            {/* Search Bar */}
            <div className="hidden md:flex flex-1 max-w-xl mx-8">
              <div className="relative w-full">
                <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="ابحث عن سيارة، عقار، هاتف..."
                  className="w-full bg-gray-800 text-white placeholder-gray-400 rounded-xl py-2 pr-12 pl-4 border border-gray-700 focus:border-amber-400" />
              </div>
            </div>

            {/* Desktop Menu */}
            <div className="hidden lg:flex items-center gap-3">
              <button onClick={toggleDarkMode} className="p-2 rounded-xl bg-gray-800 text-amber-400 hover:bg-gray-700">
                {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
              </button>
              <button onClick={() => setShowNotifications(true)} className="p-2 rounded-xl bg-gray-800 text-white hover:bg-gray-700 relative">
                <Bell className="w-5 h-5" />
                {notifications.length > 0 && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full text-xs text-white flex items-center justify-center">
                    {notifications.length}
                  </span>
                )}
              </button>
              <button onClick={() => setShowCreateAd(true)}
                className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-amber-500 to-yellow-500 text-black font-bold rounded-xl">
                <Plus className="w-5 h-5" />
                <span>رفع إعلان</span>
              </button>
              <button onClick={handleLogout} className="p-2 rounded-xl bg-red-500/20 text-red-400 hover:bg-red-500/30">
                <LogOut className="w-5 h-5" />
              </button>
            </div>

            <button onClick={() => setShowMobileMenu(!showMobileMenu)} className="lg:hidden p-2 rounded-xl bg-gray-800 text-white">
              <Menu className="w-6 h-6" />
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu */}
      {showMobileMenu && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/60" onClick={() => setShowMobileMenu(false)} />
          <div className="absolute right-0 top-0 bottom-0 w-80 bg-gray-900 p-6 overflow-y-auto">
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-900 rounded-xl flex items-center justify-center">
                  <span className="text-amber-400">🇮🇶</span>
                </div>
                <div>
                  <h2 className="text-lg font-bold text-white">سوك بغداد</h2>
                  <p className="text-xs text-amber-400">مرحباً {user?.name}</p>
                </div>
              </div>
              <button onClick={() => setShowMobileMenu(false)} className="p-2 bg-gray-800 rounded-xl text-white">
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* User Profile Card */}
            <div className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-2xl p-4 mb-6 border border-gray-700">
              <div className="flex items-center gap-4 mb-4">
                <img src={user?.avatar} alt={user?.name} className="w-16 h-16 rounded-full border-2 border-amber-500" />
                <div className="flex-1">
                  <h3 className="text-white font-bold">{user?.name}</h3>
                  <p className="text-gray-400 text-sm">{user?.email}</p>
                  <div className="flex items-center gap-1 text-amber-400 text-sm mt-1">
                    <Star className="w-4 h-4 fill-amber-400" />
                    <span>{user?.rating || 4.5}</span>
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-3 text-center">
                <div className="bg-gray-700/50 rounded-xl p-2">
                  <p className="text-xl font-bold text-amber-400">{user?.stats?.ads || 0}</p>
                  <p className="text-xs text-gray-400">إعلان</p>
                </div>
                <div className="bg-gray-700/50 rounded-xl p-2">
                  <p className="text-xl font-bold text-amber-400">{favorites.length}</p>
                  <p className="text-xs text-gray-400">مفضلة</p>
                </div>
                <div className="bg-gray-700/50 rounded-xl p-2">
                  <p className="text-xl font-bold text-amber-400">{user?.stats?.views || 0}</p>
                  <p className="text-xs text-gray-400">مشاهدة</p>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              {categories.map((cat) => (
                <button key={cat.id} onClick={() => {
                  setSelectedCategory(cat.id);
                  if (cat.id === 'games') setCurrentView('games');
                  setShowMobileMenu(false);
                }}
                  className="w-full flex items-center gap-4 p-3 rounded-xl hover:bg-gray-800 transition-colors">
                  <span className="text-2xl">{cat.emoji}</span>
                  <span className="text-white font-medium">{cat.name}</span>
                </button>
              ))}
            </div>

            <div className="mt-6 pt-6 border-t border-gray-800 space-y-2">
              <button onClick={() => { setShowCreateAd(true); setShowMobileMenu(false); }}
                className="w-full flex items-center gap-4 p-3 rounded-xl bg-amber-500 text-black font-bold">
                <Plus className="w-5 h-5" />
                <span>رفع إعلان</span>
              </button>
              <button onClick={() => { setShowNotifications(true); setShowMobileMenu(false); }}
                className="w-full flex items-center gap-4 p-3 rounded-xl hover:bg-gray-800">
                <Bell className="w-5 h-5 text-amber-400" />
                <span className="text-white">الإشعارات</span>
                {notifications.length > 0 && (
                  <span className="mr-auto px-2 py-0.5 bg-red-500 rounded-full text-xs text-white">{notifications.length}</span>
                )}
              </button>
              <button onClick={toggleDarkMode} className="w-full flex items-center gap-4 p-3 rounded-xl hover:bg-gray-800">
                {darkMode ? <Sun className="w-5 h-5 text-amber-400" /> : <Moon className="w-5 h-5 text-blue-400" />}
                <span className="text-white">{darkMode ? 'الوضع الفاتح' : 'الوضع الداكن'}</span>
              </button>
              <button onClick={handleLogout} className="w-full flex items-center gap-4 p-3 rounded-xl hover:bg-gray-800 text-red-400">
                <LogOut className="w-5 h-5" />
                <span>تسجيل الخروج</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="pt-24 pb-12">
        {/* Hero Section */}
        <section className="bg-gradient-to-br from-blue-900 via-blue-800 to-blue-900 py-16 relative overflow-hidden">
          <div className="absolute inset-0">
            <div className="absolute top-20 right-10 w-40 h-40 bg-amber-500/20 rounded-full blur-3xl" />
            <div className="absolute bottom-20 left-10 w-60 h-60 bg-blue-400/20 rounded-full blur-3xl" />
          </div>
          <div className="container mx-auto px-4 relative z-10 text-center">
            <motion.h1 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
              className="text-4xl md:text-5xl font-bold text-white mb-4">
              كل شي تحتاجه <span className="text-amber-400">بمكان واحد</span>
            </motion.h1>
            <p className="text-gray-300 text-lg mb-8">سوق العراق الرقمي الحديث</p>

            <div className="flex flex-wrap justify-center gap-3">
              {categories.slice(1).map((cat) => (
                <motion.button key={cat.id} whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}
                  onClick={() => {
                    if (cat.id === 'games') setCurrentView('games');
                    else setSelectedCategory(cat.id);
                  }}
                  className="flex items-center gap-2 px-5 py-2 bg-white/10 backdrop-blur rounded-xl text-white font-medium border border-white/20 hover:bg-white/20">
                  <span>{cat.emoji}</span>
                  <span>{cat.name}</span>
                </motion.button>
              ))}
            </div>
          </div>
        </section>

        {/* Ads Section */}
        <section className="py-12">
          <div className="container mx-auto px-4">
            {/* Filter Bar */}
            <div className="flex flex-wrap items-center justify-between gap-4 mb-8">
              <h2 className="text-2xl font-bold text-white">
                {selectedCategory === 'all' ? 'جميع الإعلانات' : categories.find((c) => c.id === selectedCategory)?.name}
                <span className="text-gray-400 text-lg mr-2">({filteredAds.length})</span>
              </h2>

              <div className="flex items-center gap-3 flex-wrap">
                <select value={selectedCategory} onChange={(e) => setSelectedCategory(e.target.value)}
                  className="bg-gray-800 text-white rounded-xl px-4 py-2 border border-gray-700">
                  {categories.map((cat) => <option key={cat.id} value={cat.id}>{cat.name}</option>)}
                </select>

                <select value={sortBy} onChange={(e) => setSortBy(e.target.value as any)}
                  className="bg-gray-800 text-white rounded-xl px-4 py-2 border border-gray-700">
                  <option value="recent">الأحدث</option>
                  <option value="views">الأكثر مشاهدة</option>
                  <option value="price-low">السعر: من الأقل</option>
                  <option value="price-high">السعر: من الأعلى</option>
                </select>

                <div className="flex bg-gray-800 rounded-xl p-1">
                  <button onClick={() => setViewMode('grid')}
                    className={`p-2 rounded-lg ${viewMode === 'grid' ? 'bg-amber-500 text-black' : 'text-gray-400'}`}>
                    <Grid className="w-5 h-5" />
                  </button>
                  <button onClick={() => setViewMode('list')}
                    className={`p-2 rounded-lg ${viewMode === 'list' ? 'bg-amber-500 text-black' : 'text-gray-400'}`}>
                    <List className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>

            {/* Ads Grid/List */}
            <div className={viewMode === 'grid' ? 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6' : 'space-y-4'}>
              {filteredAds.map((ad) => (
                <motion.div key={ad.id} whileHover={{ y: -5 }} onClick={() => setSelectedAd(ad)}
                  className={`bg-gray-800 rounded-2xl overflow-hidden border border-gray-700 hover:border-amber-500/50 cursor-pointer ${viewMode === 'list' ? 'flex' : ''}`}>
                  <div className={`relative ${viewMode === 'list' ? 'w-48' : 'aspect-[4/3]'} ${viewMode === 'list' ? 'h-48' : ''}`}>
                    <img src={ad.images[0]} alt={ad.title} className="w-full h-full object-cover" />
                    {ad.type === 'rent' && (
                      <div className="absolute top-3 left-3 px-2 py-1 bg-blue-500 rounded-full text-xs font-bold text-white">
                        للإيجار
                      </div>
                    )}
                    <button onClick={(e) => { e.stopPropagation(); toggleFavorite(ad.id); }}
                      className={`absolute top-3 right-3 w-10 h-10 rounded-full flex items-center justify-center ${favorites.includes(ad.id) ? 'bg-red-500' : 'bg-black/50'}`}>
                      {favorites.includes(ad.id) ? (
                        <Heart className="w-5 h-5 text-white fill-current" />
                      ) : (
                        <Heart className="w-5 h-5 text-white" />
                      )}
                    </button>
                    {ad.seller.isVerified && (
                      <div className="absolute bottom-3 left-3 px-2 py-1 bg-blue-500 rounded-full text-xs font-bold text-white flex items-center gap-1">
                        <Shield className="w-3 h-3" />
                        موثق
                      </div>
                    )}
                  </div>
                  <div className={`p-4 ${viewMode === 'list' ? 'flex-1' : ''}`}>
                    <h3 className="text-white font-bold mb-2 line-clamp-1">{ad.title}</h3>
                    <p className="text-xl font-bold text-amber-400 mb-2">{formatPrice(ad.price)} د.ع</p>
                    <div className="flex items-center gap-2 text-gray-400 text-sm mb-3">
                      <MapPin className="w-4 h-4" />
                      <span className="line-clamp-1">{ad.location}</span>
                    </div>
                    <div className="flex items-center justify-between text-gray-500 text-xs">
                      <div className="flex items-center gap-1">
                        <Star className="w-3 h-3 text-amber-400 fill-amber-400" />
                        <span>{ad.seller.rating}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span>{ad.time}</span>
                        <div className="flex items-center gap-1">
                          <ViewIcon className="w-3 h-3" />
                          <span>{ad.views}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Entertainment Section */}
        <section className="py-12 bg-gradient-to-br from-purple-900 via-blue-900 to-purple-900">
          <div className="container mx-auto px-4">
            <div className="text-center mb-8">
              <span className="inline-flex items-center gap-2 bg-amber-500/20 px-4 py-2 rounded-full mb-4">
                <Gamepad2 className="w-5 h-5 text-amber-400" />
                <span className="text-amber-400 font-semibold">قسم الترفيه</span>
              </span>
              <h2 className="text-3xl font-bold text-white mb-2">🎮 الألعاب الترفيهية</h2>
              <p className="text-gray-300">اضغط وابدأ اللعب مباشرة!</p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              {gamesData.map((game) => (
                <motion.div key={game.id} whileHover={{ scale: 1.05, y: -5 }} whileTap={{ scale: 0.95 }}
                  onClick={() => setCurrentView('games')}
                  className="bg-white/10 backdrop-blur rounded-2xl p-4 text-center border border-white/20 cursor-pointer hover:bg-white/20">
                  <div className="text-4xl mb-2">{game.emoji}</div>
                  <h3 className="text-white font-bold text-sm mb-1">{game.title}</h3>
                  <div className="flex items-center justify-center gap-1 text-gray-300 text-xs">
                    <Star className="w-3 h-3 text-amber-400 fill-amber-400" />
                    <span>{game.rating}</span>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 border-t border-gray-800 py-8">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
            <span className="text-2xl">🇮🇶</span>
            <span className="text-xl font-bold text-white">سوك بغداد</span>
          </div>
          <p className="text-gray-400 text-sm">© 2024 سوك بغداد - السوق الرقمي العراقي</p>
          <div className="flex items-center justify-center gap-4 mt-4">
            <div className="w-4 h-4 bg-white rounded-full" />
            <div className="w-4 h-4 bg-black rounded-full" />
            <div className="w-4 h-4 bg-red-600 rounded-full" />
          </div>
          <p className="text-gray-500 text-xs mt-2">🇮🇶 العراق</p>
        </div>
      </footer>

      {/* Modals */}
      <CreateAdModal isOpen={showCreateAd} onClose={() => setShowCreateAd(false)}
        onSubmit={(data) => { console.log('New ad:', data); showToast('تم نشر الإعلان بنجاح!', 'success'); }}
        user={user} />

      <AdDetailModal ad={selectedAd} onClose={() => setSelectedAd(null)}
        onFavorite={() => selectedAd && toggleFavorite(selectedAd.id)}
        isFavorite={selectedAd ? favorites.includes(selectedAd.id) : false} />

      <NotificationsPanel isOpen={showNotifications} onClose={() => setShowNotifications(false)} notifications={notifications} />
    </div>
  );
}

// Main App Component
export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    const savedUser = localStorage.getItem('souqUser');
    if (savedUser) {
      try {
        setUser(JSON.parse(savedUser));
        setIsLoggedIn(true);
      } catch {
        localStorage.removeItem('souqUser');
      }
    }

    const savedTheme = localStorage.getItem('souqTheme');
    if (savedTheme === 'light') {
      document.documentElement.classList.remove('dark');
    }
  }, []);

  const handleLogin = () => {
    const savedUser = localStorage.getItem('souqUser');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
      setIsLoggedIn(true);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('souqUser');
    setUser(null);
    setIsLoggedIn(false);
  };

  return (
    <div className="dark">
      <AnimatePresence mode="wait">
        {isLoggedIn && user ? (
          <motion.div key="main" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            <MainApp user={user} onLogout={handleLogout} />
          </motion.div>
        ) : (
          <motion.div key="auth" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <AuthPage onLogin={handleLogin} />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}